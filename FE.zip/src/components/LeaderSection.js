import React from 'react';
import './LeaderSection.css';

const LeaderSection = () => {
  const leaders = [
    {
      id: 1,
      name: "Sam Altman",
      title: "is an American entrepreneur who was president of the start-up accelerator Y Combinator from 2014 to 2019 and CEO of the AI company OpenAI beginning in 2019.",
      image: "https://i.pravatar.cc/150?img=33",
      social: {
        linkedin: "#",
        twitter: "#"
      }
    },
    {
      id: 2,
      name: "Robert Steve",
      title: "is an American entrepreneur who was president of the start-up accelerator Y Combinator from 2014 to 2019 and CEO of the AI company OpenAI beginning in 2019.",
      image: "https://i.pravatar.cc/150?img=12",
      social: {
        facebook: "#",
        linkedin: "#"
      }
    },
    {
      id: 3,
      name: "Robert Steve",
      title: "is an American entrepreneur who was president of the start-up accelerator Y Combinator from 2014 to 2019 and CEO of the AI company OpenAI beginning in 2019.",
      image: "https://i.pravatar.cc/150?img=11",
      social: {
        youtube: "#",
        linkedin: "#"
      }
    },
    {
      id: 4,
      name: "Robert Steve",
      title: "is an American entrepreneur who was president of the start-up accelerator Y Combinator from 2014 to 2019 and CEO of the AI company OpenAI beginning in 2019.",
      image: "https://i.pravatar.cc/150?img=14",
      social: {
        youtube: "#",
        twitter: "#"
      }
    }
  ];

  return (
    <section className="leader-section">
      <h2 className="section-title text-orange">Meet our leaders</h2>
      <div className="leaders-grid">
        {leaders.map(leader => (
          <div key={leader.id} className="leader-card">
            <img src={leader.image} alt={leader.name} className="leader-image" />
            <h3 className="leader-name">{leader.name}</h3>
            <div className="leader-social">
              {leader.social.facebook && <a href={leader.social.facebook}>📘</a>}
              {leader.social.twitter && <a href={leader.social.twitter}>🐦</a>}
              {leader.social.linkedin && <a href={leader.social.linkedin}>💼</a>}
              {leader.social.youtube && <a href={leader.social.youtube}>📺</a>}
            </div>
            <p className="leader-title">{leader.title}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default LeaderSection;
