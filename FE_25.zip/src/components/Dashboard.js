import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import blogService from '../services/blogService';
import './Dashboard.css';

const Dashboard = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [myPosts, setMyPosts] = useState([]);
    const [recentPosts, setRecentPosts] = useState([]);
    const [popularPosts, setPopularPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('my-posts');

    useEffect(() => {
        loadDashboardData();
    }, []);

    const loadDashboardData = async () => {
        setLoading(true);
        try {
            // Load user's posts
            const myPostsResponse = await blogService.getAllPosts({
                my_posts: 'true',
                limit: 20
            });
            setMyPosts(myPostsResponse.posts || []);

            // Load recent posts
            const recentResponse = await blogService.getRecentPosts(10);
            setRecentPosts(recentResponse.posts || []);

            // Load popular posts
            const popularResponse = await blogService.getPopularPosts(10);
            setPopularPosts(popularResponse.posts || []);
        } catch (err) {
            console.error('Failed to load dashboard data:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleDeletePost = async (postId) => {
        if (!window.confirm('Are you sure you want to delete this post?')) return;

        try {
            await blogService.deletePost(postId);
            setMyPosts(myPosts.filter(post => post.id !== postId));
            alert('Post deleted successfully');
        } catch (err) {
            alert('Failed to delete post');
        }
    };

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };

    if (loading) {
        return <div className="loading">Loading dashboard...</div>;
    }

    return (
        <div className="dashboard-container">
            <div className="dashboard-header">
                <div>
                    <h1>Welcome, {user.first_name}!</h1>
                    <p>Manage your blog posts and view analytics</p>
                </div>
                <div className="header-actions">
                    <Link to="/blog/new" className="create-post-btn">
                        + Create New Post
                    </Link>
                    <button onClick={handleLogout} className="logout-btn">
                        Logout
                    </button>
                </div>
            </div>

            <div className="dashboard-stats">
                <div className="stat-card">
                    <h3>Total Posts</h3>
                    <p className="stat-number">{myPosts.length}</p>
                </div>
                <div className="stat-card">
                    <h3>Published</h3>
                    <p className="stat-number">
                        {myPosts.filter(p => p.status === 'published').length}
                    </p>
                </div>
                <div className="stat-card">
                    <h3>Drafts</h3>
                    <p className="stat-number">
                        {myPosts.filter(p => p.status === 'draft').length}
                    </p>
                </div>
                <div className="stat-card">
                    <h3>Total Views</h3>
                    <p className="stat-number">
                        {myPosts.reduce((sum, post) => sum + (post.view_count || 0), 0)}
                    </p>
                </div>
            </div>

            <div className="dashboard-tabs">
                <button
                    className={activeTab === 'my-posts' ? 'tab active' : 'tab'}
                    onClick={() => setActiveTab('my-posts')}
                >
                    My Posts
                </button>
                <button
                    className={activeTab === 'recent' ? 'tab active' : 'tab'}
                    onClick={() => setActiveTab('recent')}
                >
                    Recent Posts
                </button>
                <button
                    className={activeTab === 'popular' ? 'tab active' : 'tab'}
                    onClick={() => setActiveTab('popular')}
                >
                    Popular Posts
                </button>
            </div>

            <div className="dashboard-content">
                {activeTab === 'my-posts' && (
                    <div className="posts-table">
                        <h2>My Posts</h2>
                        {myPosts.length === 0 ? (
                            <div className="no-posts">
                                <p>You haven't created any posts yet.</p>
                                <Link to="/blog/new">Create your first post</Link>
                            </div>
                        ) : (
                            <table>
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Views</th>
                                        <th>Comments</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {myPosts.map(post => (
                                        <tr key={post.id}>
                                            <td>
                                                <Link to={`/blog/${post.slug}`}>
                                                    {post.title}
                                                </Link>
                                            </td>
                                            <td>
                                                <span className={`status ${post.status}`}>
                                                    {post.status}
                                                </span>
                                            </td>
                                            <td>{post.view_count || 0}</td>
                                            <td>{post.comment_count || 0}</td>
                                            <td>{formatDate(post.created_date)}</td>
                                            <td className="actions">
                                                <button
                                                    onClick={() => navigate(`/blog/edit/${post.id}`)}
                                                    className="edit-btn"
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    onClick={() => handleDeletePost(post.id)}
                                                    className="delete-btn"
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                )}

                {activeTab === 'recent' && (
                    <div className="posts-list">
                        <h2>Recent Posts</h2>
                        {recentPosts.map(post => (
                            <div key={post.id} className="post-item">
                                <h3>
                                    <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                                </h3>
                                <p className="post-meta">
                                    By {post.author_first_name} {post.author_last_name} • 
                                    {formatDate(post.published_date)}
                                </p>
                                <p className="post-excerpt">{post.excerpt}</p>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'popular' && (
                    <div className="posts-list">
                        <h2>Popular Posts</h2>
                        {popularPosts.map(post => (
                            <div key={post.id} className="post-item">
                                <h3>
                                    <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                                </h3>
                                <p className="post-meta">
                                    By {post.author_first_name} {post.author_last_name} • 
                                    {post.view_count} views
                                </p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Dashboard;
